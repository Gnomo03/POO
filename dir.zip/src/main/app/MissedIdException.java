package app;

public class MissedIdException extends Exception {

    /**
     * Constructs a new MissedIdException with no detail message.
     */
    public MissedIdException() {
        super();
    }

}
