package app;

/**
 * An interface representing a premium item.
 */
public interface Premium {

}